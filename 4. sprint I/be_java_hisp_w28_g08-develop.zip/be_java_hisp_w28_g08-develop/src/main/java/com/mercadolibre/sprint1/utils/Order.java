package com.mercadolibre.sprint1.utils;

public enum Order {
    NAME_ASC,
    NAME_DESC
}

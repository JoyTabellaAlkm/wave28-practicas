package com.mercadolibre.sprint1.exception;

public class PromoSellersNotFoundException extends RuntimeException {
    public PromoSellersNotFoundException(String message) {
        super(message);
    }
}

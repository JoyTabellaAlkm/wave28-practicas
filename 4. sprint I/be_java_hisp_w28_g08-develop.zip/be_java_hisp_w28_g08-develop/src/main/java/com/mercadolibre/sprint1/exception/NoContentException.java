package com.mercadolibre.sprint1.exception;

public class NoContentException extends RuntimeException {
    public NoContentException(String message) {

        super(message);
    }
}

package com.bootcamp.socialmeli.util.validation;

public class ValidationRegex {
    public static final String ALPHANUMERIC_ONLY = "^[a-zA-Z0-9\\s]*$";
}
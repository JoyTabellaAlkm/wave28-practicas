package com.bootcamp.socialmeli.exception;

public class IllegalFollowException extends RuntimeException{
    public IllegalFollowException(String message){
        super(message);
    }
}
